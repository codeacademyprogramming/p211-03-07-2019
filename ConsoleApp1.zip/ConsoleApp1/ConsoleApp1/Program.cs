﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main()
        {
            //int a = 5; //variable declaration and assignment

            //int b = a;

            //a += 10;
            //b *= 2;

            //Console.WriteLine(a);
            //Console.WriteLine(b);

            int[] numbers = new[] { 10, 12, 32 };
            int[] numbers2 = numbers;

            numbers2[1] = 100;

            Console.WriteLine(numbers[1]);
            Console.WriteLine(numbers2[1]);
        }

        #region Methods
        //static int SumEven(params int[] numbers)
        //{
        //    int total = 0;
        //    foreach (int item in numbers)
        //    {
        //        if(item % 2 == 0)
        //        {
        //            total += item;
        //        }
        //    }

        //    return total;
        //}

        //static int[] Add(int a, int b)
        //{
        //    if(a > b)
        //    {
        //        return new int[] { 12, 10, 34, 54, 65 };
        //    }

        //    return new int[] { 10, 32, 54 };
        //}
        #endregion

    }
}
